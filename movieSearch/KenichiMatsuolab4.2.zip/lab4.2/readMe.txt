Creative portions:
1) watch YouTube and the actual movie
When user picks on the movie either in their favorite tab or in the results tab they can choose to 
Watch a trailer for the movie through YouTube or watch the entire movies with 123 movies. This was done with the safari library being imported and with a search query from YouTube


2) sort the results by ratings vs by relevancy
The function passes in a comparator into the sorting algorithm and chooses an element of the struct
To have the array be sorted it based off of. When the user selects whether or not to sort the array
By rating there are two arrays, one based off of relevancy and the other ordered on ratings, and
They are swapped

3) the tenner (storing UIImages and all of the movie info locally)
It is the same code for displaying all of the information in the new view controller being pushed 
This is done with user defaults via the Codable struct

4) when the user opens the page it displays the top 20 trending results before the user types in a query
this was done by having a different API uri under viewdidload of the viewcontroller class



