//
//  SlidingViewController.swift
//  lab4.2
//
//  Created by Kenichi Matsuo on 10/28/21.
//

import UIKit
import SafariServices

class SlidingViewController: UIViewController {
    @IBOutlet weak var UIimage: UIImageView!
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var pgRating: UILabel!
    @IBOutlet weak var dateReleased: UILabel!
    @IBOutlet weak var safari: UIButton!
    
    @IBOutlet weak var descript: UILabel!
    @IBOutlet weak var bttn: UIButton!
    @IBOutlet weak var favButton: UIButton!
    var getRating: String = ""
    var getTitle: String = ""
    var getUiImage = UIImage()
    //var getMovieID = ""
    var getReleased: String = ""
    var isHidden = false
    var getDesc = ""
    var leftTrailer = "http://api.themoviedb.org/3/movie/"
    var rightTrailer = "/videos?api_key=e43407eb85b2c61aad682c92b6a1c85b"
    var apiKey = "e43407eb85b2c61aad682c92b6a1c85b"
    override func viewDidLoad() {
        super.viewDidLoad()
        rating.text = getRating
        descript.text = getDesc
        pgRating.text = getTitle
        UIimage.image = getUiImage
        dateReleased.text = getReleased
        bttn.isHidden = isHidden
        
    }
    @IBAction func youtube(_ sender: Any) {
        //https://www.youtube.com/results?search_query=crump
        let name = getTitle.replacingOccurrences(of: " ", with: "+")
        let altLink = "https://www.youtube.com/results?search_query="+name
        let link = SFSafariViewController(url: URL(string: altLink)!)
        present(link, animated: true)
    }
    @IBAction func safari(_ sender: Any) {
        let name = getTitle.replacingOccurrences(of: " ", with: "+")
        let altLink = "https://ww5.0123movie.net/search/"+name+".html"
        //let altLink = "https://9movies.ro/movie/search?keyword="+name
        let link = SFSafariViewController(url: URL(string: altLink)!)
        present(link, animated: true)
    }
    
    @IBAction func add2FavBtn(_ sender: Any) {
        //print("shizzz")
        let myDouble = Double(getRating) ?? 0.0
        print("desc "+getDesc)
        let newFav = codableMovie(title: getTitle, release_date: getReleased, vote_average: myDouble, posterImg: getUiImage, descript: getDesc)
        
        var isIn = false
        for i in favArray{
            if i.title == newFav.title{
                isIn = true
                break
            }
        }
        if !isIn{
            favArray.append(newFav)
        }
        if let data = try? PropertyListEncoder().encode(favArray){
            UserDefaults.standard.set(data, forKey: defaultKey)
        }
        print(favArray.count)
    }
    

}
