//
//  ViewController.swift
//  lab4.2
//
//  Created by Kenichi Matsuo on 10/28/21.
//

import UIKit

struct APIResults:Decodable {
    let page: Int
    let total_results: Int
    let total_pages: Int
    let results: [Movie]
}
struct Movie: Decodable {
    let id: Int!
    let poster_path: String?
    let title: String
    let release_date: String?
    let vote_average: Double
    let overview: String
    let vote_count:Int!
}

struct codableMovie: Codable{
    var title: String
    var release_date: String?
    var vote_average: Double
    var posterImg: UIImage
    var descript: String
    enum CodingKeys: String, CodingKey{
        case title; case release_date; case vote_average; case poster_Img; case descript
    }
    init(title: String, release_date: String?, vote_average: Double, posterImg: UIImage, descript: String){
        self.title = title; self.release_date = release_date; self.vote_average = vote_average; self.posterImg = posterImg; self.descript = descript
    }
    func encode(to encoder: Encoder) throws {
        var container = encoder.container(keyedBy: CodingKeys.self)
        try container.encode(title, forKey: .title)
        try container.encode(release_date, forKey: .release_date)
        try container.encode(vote_average, forKey: .vote_average)
        try container.encode(posterImg.pngData(), forKey: .poster_Img)
        try container.encode(descript, forKey: .descript)
        
    }
    init(from decoder: Decoder) throws{
        let container = try decoder.container(keyedBy: CodingKeys.self)
        title = try container.decode(String.self, forKey: .title)
        release_date = try container.decode(String.self, forKey: .release_date)
        vote_average = try container.decode(Double.self, forKey: .vote_average)
        descript = try container.decode(String.self, forKey: .descript)
        let imgData = try container.decode(Data.self, forKey: .poster_Img)
        guard let actualIMG = UIImage(data: imgData) else{
            throw DecodingError.dataCorruptedError(forKey: .poster_Img, in: container, debugDescription: "IMG not added right")
        }
        self.posterImg = actualIMG
    }
}

var movieData: [Movie] = []
var alteredMovieData: [Movie] = []
var apiData: [APIResults] = []
var imageCache: [UIImage] = []
var alteredImageCache: [UIImage] = []
let defaults = UserDefaults.standard
var isOrderRating = false
//below if i give up
//let favArray = defaults.stringArray(forKey: "favArray") ?? [String]()
var favArray: [codableMovie] = []
let defaultKey = "SavedItemArray"

class ViewController: UIViewController, UISearchBarDelegate, UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    
    
    @IBOutlet weak var spinner: UIActivityIndicatorView!
    

    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var collectionView: UICollectionView!
    //https://www.youtube.com/watch?v=SUXWAEX2jlg
    //http://api.themoviedb.org/3/movie/157336/videos?api_key=###
    
    var apiKey = "e43407eb85b2c61aad682c92b6a1c85b"
    var searchAPIleft = "https://api.themoviedb.org/3/search/movie?api_key=e43407eb85b2c61aad682c92b6a1c85b&language=en-US&query="
    var searchAPIright = "&page=1&include_adult=true"
    var apiUrlLeft = "https://api.themoviedb.org/3/movie/"
    var apiUrlRight = "?api_key=e43407eb85b2c61aad682c92b6a1c85b"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        spinner.hidesWhenStopped = true
        spinner.startAnimating()
        DispatchQueue.global(qos: .userInitiated).async {
            self.fetchDataForTableView(query: "ac54bc")
            self.cacheImages()
            DispatchQueue.main.async {
                self.collectionView.reloadData()
                self.spinner.stopAnimating()
            }
        }
        //fetchDataForTableView(query: "Bee")
        //cacheImages()
        searchBar.delegate = self
        collectionView.delegate = self
        collectionView.dataSource = self
        
        
       
        // Do any additional setup after loading the view.
    }
    func fetchDataForTableView(query: String){
        let altQuery = query.replacingOccurrences(of: " ", with: "%20")
        var movieURL = URL(string: searchAPIleft+altQuery+searchAPIright)
        if query == "ac54bc"{
            movieURL = URL(string: "https://api.themoviedb.org/3/trending/movie/week?api_key=e43407eb85b2c61aad682c92b6a1c85b")
        }
        let tempData = try! Data(contentsOf: movieURL!)
        let result = try! JSONDecoder().decode(APIResults.self, from: tempData)
        
        movieData = result.results
        alteredMovieData = movieData
        alteredMovieData = alteredMovieData.sorted(by: {$0.vote_average < $1.vote_average})
        
        
    }
    
    
    //let user order the results
    
    @IBAction func cunt(_ sender: Any) {
        print(movieData.count)
        print(alteredMovieData.count)
        let tempImageCache: [UIImage] = imageCache
        let tempMovieData: [Movie] = movieData
        imageCache = alteredImageCache
        movieData = alteredMovieData
        alteredImageCache = tempImageCache
        alteredMovieData = tempMovieData
        collectionView.reloadData()
    }
    
    
    func cacheImages(){
        var index = 0
        var iindex = 0
        for item in movieData{
            let tempFML = item.poster_path ?? ""
            let tempURL = URL(string: "https://www.themoviedb.org/t/p/w220_and_h330_face/\(tempFML)")
            if tempFML == ""{
                movieData.remove(at: index)
            }else{
                let tempData = try? Data(contentsOf: tempURL!)
                let tempImg = UIImage(data: tempData!)
                imageCache.append(tempImg!)
                index = index+1
            }
            
        }
        
        for i in alteredMovieData{
            let fml = i.poster_path ?? ""
            let tempURL = URL(string: "https://www.themoviedb.org/t/p/w220_and_h330_face/\(fml)")
            if fml == ""{
                alteredMovieData.remove(at: iindex)
            }else{
                let tempData = try? Data(contentsOf: tempURL!)
                let tempImg = UIImage(data: tempData!)
                alteredImageCache.append(tempImg!)
                iindex = iindex+1
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //return a cgsize object w/that
        let size = CGSize(width: 140, height: 231)
        return size
    }
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        spinner.startAnimating()
        let tempStr:String = searchBar.text ?? ""
        if tempStr != ""{
            print(tempStr)
            movieData = []
            imageCache = []
            alteredImageCache = []
            alteredMovieData = []
            DispatchQueue.global(qos: .userInitiated).async {
                self.fetchDataForTableView(query: tempStr)
                alteredMovieData = movieData
                alteredMovieData = alteredMovieData.sorted(by: {$0.vote_average < $1.vote_average})
                self.cacheImages()
                DispatchQueue.main.async {
                    self.collectionView.reloadData()
                    self.spinner.stopAnimating()
                }
            }
            
        }
        
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //what to do when one of em is selected
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let slidingView = storyboard.instantiateViewController(identifier: "slidingViewController") as! SlidingViewController
        
        
        slidingView.getDesc = movieData[indexPath.row].overview
        
        slidingView.getReleased = movieData[indexPath.row].release_date ?? ""
        slidingView.getTitle = movieData[indexPath.row].title
        slidingView.getRating = "Rating: "+String(movieData[indexPath.row].vote_average)
        slidingView.getUiImage = imageCache[indexPath.row]
        navigationController?.pushViewController(slidingView, animated: true)
        
        // Do any additional setup after loading the view.
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as! tempCollectionViewCell
        let tempPoster = imageCache[indexPath.row]
        let tempPosterWord = movieData[indexPath.row].title
        cell.movieImgView.image = tempPoster
        cell.movieLabel.text = tempPosterWord
        
        
        return cell
        
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
 
    
 
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageCache.count
    }


}

