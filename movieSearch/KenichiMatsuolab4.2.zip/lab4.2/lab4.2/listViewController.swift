//
//  listViewController.swift
//  lab4.2
//
//  Created by Kenichi Matsuo on 10/28/21.
//

import Foundation
import UIKit

var numFavorites = 0 //global variable tracking number of favorited items

class ListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        tableView.reloadData()
        
        
        
        print(favArray.count)
        if let data = defaults.data(forKey: defaultKey){
            let arr = try! PropertyListDecoder().decode([codableMovie].self, from: data)
            favArray = arr
        }
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
        
    }
    func setupTableView(){
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: "cell")
        cell.textLabel!.text = favArray[indexPath.row].title
        
        cell.imageView?.image = favArray[indexPath.row].posterImg
        
        return cell
    }
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            favArray.remove(at: indexPath.row)
            if let ddata = try? PropertyListEncoder().encode(favArray){
                UserDefaults.standard.set(ddata, forKey: defaultKey)
            }
            tableView.deleteRows(at: [indexPath], with: .left)
            
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let slidingView = storyboard.instantiateViewController(identifier: "slidingViewController") as! SlidingViewController
        slidingView.getDesc = favArray[indexPath.row].descript
        slidingView.getReleased = favArray[indexPath.row].release_date ?? ""
        slidingView.getTitle = favArray[indexPath.row].title
        slidingView.getRating = "Rating: "+String(favArray[indexPath.row].vote_average)
        slidingView.getUiImage = favArray[indexPath.row].posterImg
        slidingView.isHidden = true
        navigationController?.pushViewController(slidingView, animated: true)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return favArray.count
    }
    

    
}


