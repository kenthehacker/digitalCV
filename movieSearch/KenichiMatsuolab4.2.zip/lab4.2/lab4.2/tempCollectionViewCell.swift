//
//  tempCollectionViewCell.swift
//  lab4.2
//
//  Created by Kenichi Matsuo on 10/28/21.
//

import UIKit

class tempCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var movieImgView: UIImageView!
    
    @IBOutlet weak var movieLabel: UILabel!
    
    
    
}
